# QuantumPay: Digital Payment Gateway (Vulnerable Baseline)

> **Security Posture:** ❌ Classical Cryptographic Debt Detected  
> **Quantum Readiness:** Anticipated Score: **~25 / 100**  
> **HNDL Threat:** Active Asymmetric Key Exchange & Elliptic Curve Vulnerabilities

This repository represents the **Pre-Migration Baseline** of a digital payment gateway microservice. It contains:
* **RSA-2048 Key Generation** in `services/payment_encryption.py` (HNDL critical vulnerability).
* **ECC SECP256R1 Digital Signatures** in `services/token_auth.py` (Quantum-vulnerable authorization).
* **MD5 & SHA-1 Hashing** in `services/credential_hasher.py` (Classical collision weakness).
* **Legacy Cryptographic Dependencies** in `requirements.txt` (`pycryptodome`, `pycrypto`) and `package.json` (`crypto-js`).

Use this directory or `QuantumPay_Before_Migration.zip` as the **Baseline Scan** in Keynova.
