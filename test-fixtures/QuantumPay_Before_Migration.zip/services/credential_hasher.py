import hashlib

class CredentialHasher:
    """
    Legacy password and transaction hashing service.
    VULNERABILITY: Uses MD5 and SHA-1.
    Suffer from classical collision attacks and zero pre-image resistance.
    """
    @staticmethod
    def hash_password(password: str) -> str:
        # MD5: Classical Weakness
        return hashlib.md5(password.encode('utf-8')).hexdigest()

    @staticmethod
    def hash_transaction_checksum(tx_data: str) -> str:
        # SHA-1: Classical Weakness
        return hashlib.sha1(tx_data.encode('utf-8')).hexdigest()
