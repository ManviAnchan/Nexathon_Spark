from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import os

class PaymentEncryptionService:
    """
    Legacy payment card encryption service.
    VULNERABILITY: Uses classical RSA-2048 key exchange.
    Subject to Shor's algorithm and Harvest-Now-Decrypt-Later (HNDL) attacks.
    """
    def __init__(self):
        # RSA-2048: Quantum-Vulnerable (HNDL Threat)
        self.private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        self.public_key = self.private_key.public_key()

    def encrypt_card_number(self, pan: str) -> bytes:
        return self.public_key.encrypt(
            pan.encode('utf-8'),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )

    def decrypt_card_number(self, ciphertext: bytes) -> str:
        decrypted = self.private_key.decrypt(
            ciphertext,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        return decrypted.decode('utf-8')
