from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
import time

class TokenAuthService:
    """
    Legacy authentication and authorization token service.
    VULNERABILITY: Uses Elliptic Curve Cryptography (SECP256R1) for digital signatures.
    Vulnerable to Shor's algorithm for discrete logarithm factorization on quantum hardware.
    """
    def __init__(self):
        # ECC SECP256R1: Quantum-Vulnerable
        self.signing_key = ec.generate_private_key(ec.SECP256R1())
        self.verify_key = self.signing_key.public_key()

    def sign_session_token(self, user_id: str) -> bytes:
        payload = f"{user_id}:{int(time.time())}".encode('utf-8')
        signature = self.signing_key.sign(
            payload,
            ec.ECDSA(hashes.SHA256())
        )
        return signature

    def verify_session_token(self, user_id: str, signature: bytes, timestamp: int) -> bool:
        payload = f"{user_id}:{timestamp}".encode('utf-8')
        try:
            self.verify_key.verify(signature, payload, ec.ECDSA(hashes.SHA256()))
            return True
        except Exception:
            return False
