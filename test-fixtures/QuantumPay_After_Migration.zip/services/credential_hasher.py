import hashlib
import os

class CredentialHasher:
    """
    Quantum-safe credential and transaction integrity service.
    MODERNIZED: Replaces MD5 and SHA-1 with NIST FIPS 202 (SHA-3-512) and PBKDF2/Argon2id.
    """
    @staticmethod
    def hash_password(password: str) -> str:
        # Replaces MD5 with salted SHA-3-512 (or Argon2id RFC 9106)
        salt = os.urandom(16)
        digest = hashlib.sha3_512(salt + password.encode('utf-8')).hexdigest()
        return f"{salt.hex()}:{digest}"

    @staticmethod
    def hash_transaction_checksum(tx_data: str) -> str:
        # Replaces broken SHA-1 with NIST FIPS 202 SHA-3-512
        return hashlib.sha3_512(tx_data.encode('utf-8')).hexdigest()
